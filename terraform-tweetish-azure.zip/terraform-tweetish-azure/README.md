# Simple Azure Function
Source code for serverless functions on Azure
